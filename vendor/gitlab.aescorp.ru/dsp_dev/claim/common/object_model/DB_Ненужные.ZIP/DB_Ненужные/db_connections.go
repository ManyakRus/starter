package object_model

import (
	"context"
	"errors"
	"fmt"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/micro"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/postgres_gorm"
	"gorm.io/gorm"
	"time"
)

type crud_db_Connection struct {
}

// Read - находит запись в БД по ID
func (crud crud_db_Connection) read(c *Connection) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.read_ctx(ctx, c)
	return err
}

// Read_ctx - находит запись в БД по ID
func (crud crud_db_Connection) read_ctx(ctx context.Context, c *Connection) error {
	var err error

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.First(c, c.ID)
	err = tx.Error

	return err
}

// Save - записывает новый или существующий объект в базу данных
func (crud crud_db_Connection) save(c *Connection) error {
	err := crud.create_update(c, false)
	return err
}

// Save_ctx - записывает новый или существующий объект в базу данных
func (crud crud_db_Connection) save_ctx(ctx context.Context, c *Connection) error {
	is_create := !micro.BoolFromInt64(c.ID)
	err := crud.create_update_ctx(ctx, c, is_create)
	return err
}

// Update - записывает существующий объект в базу данных
func (crud crud_db_Connection) update(c *Connection) error {
	err := crud.create_update(c, false)
	return err
}

// Update_ctx - записывает существующий объект в базу данных
func (crud crud_db_Connection) update_ctx(ctx context.Context, c *Connection) error {
	err := crud.create_update_ctx(ctx, c, false)
	return err
}

// Create - записывает новый объект в базу данных
func (crud crud_db_Connection) create(c *Connection) error {
	err := crud.create_update(c, true)
	return err
}

// Create_ctx - записывает новый объект в базу данных
func (crud crud_db_Connection) create_ctx(ctx context.Context, c *Connection) error {
	err := crud.create_update_ctx(ctx, c, true)
	return err
}

// create_update - записывает объект в базу данных
func (crud crud_db_Connection) create_update(c *Connection, is_create bool) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.create_update_ctx(ctx, c, is_create)
	return err
}

// create_update_ctx - записывает объект в базу данных
func (crud crud_db_Connection) create_update_ctx(ctx context.Context, c *Connection, is_create bool) error {
	var err error

	// проверка ID
	if is_create == true {
		if c.ID != 0 {
			TextError := fmt.Sprint("db.Save() ", c.TableName(), " error: id !=0")
			err = errors.New(TextError)
			return err
		}
	} else if c.ID == 0 {
		TextError := fmt.Sprint("db.Save() ", c.TableName(), " error: id =0")
		err = errors.New(TextError)
		return err
	}

	//
	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	//колонки с null
	tx := db
	MassOmit := make([]string, 0)
	//var ColumnName string

	//игнор пустых колонок
	tx = tx.Omit(MassOmit...)

	//запись
	if is_create == true {
		tx = tx.Create(c)
	} else {
		tx = tx.Save(c)
	}
	err = tx.Error
	if err != nil {
		return err
	}

	//запишем NULL в пустые колонки
	for f := 0; f < len(MassOmit); f++ {
		ColumnName := MassOmit[f]
		tx = db.First(c).Update(ColumnName, gorm.Expr("NULL"))

		err = tx.Error
		if err != nil {
			TextError := fmt.Sprint("db.Update() ", c.TableName(), " id: ", c.ID, " error: ", err)
			err = errors.New(TextError)
			return err
		}
	}

	return err
}

//// Delete - записывает is_deleted = true
//func Delete(id int64) (Connection, error) {
//	var Otvet Connection
//	var err error
//
//	ctxMain := context.Background()
//	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*TIMEOUT_DB_SECONDS)
//	defer ctxCancelFunc()
//
//	Otvet, err = Delete_ctx(ctx, id)
//	return Otvet, err
//}
//
//// Delete_ctx - записывает is_deleted = true
//func Delete_ctx(ctx context.Context, id int64) (Connection, error) {
//	var Otvet Connection
//	var err error
//
//	Otvet, err = Read_ctx(ctx, id)
//	if err != nil {
//		return Otvet, err
//	}
//
//	err = Save_ctx(ctx, &Otvet)
//
//	return Otvet, err
//}
//
//// Restore - записывает is_deleted = true
//func Restore(id int64) (Connection, error) {
//	var Otvet Connection
//	var err error
//
//	ctxMain := context.Background()
//	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*TIMEOUT_DB_SECONDS)
//	defer ctxCancelFunc()
//
//	Otvet, err = Restore_ctx(ctx, id)
//	return Otvet, err
//}
//
//// Restore_ctx - записывает is_deleted = true
//func Restore_ctx(ctx context.Context, id int64) (Connection, error) {
//	var Otvet Connection
//	var err error
//
//	Otvet, err = Read_ctx(ctx, id)
//	if err != nil {
//		return Otvet, err
//	}
//
//	err = Save_ctx(ctx, &Otvet)
//
//	return Otvet, err
//}
