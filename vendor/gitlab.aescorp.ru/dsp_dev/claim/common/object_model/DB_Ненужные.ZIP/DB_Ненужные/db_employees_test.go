package object_model

import (
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/config"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/postgres_gorm"
	"testing"
)

const Employee_ID_Test = 1

func TestEmployeeRead(t *testing.T) {
	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &Employee{}
	Model.ID = Employee_ID_Test

	crud := crud_db_Employee{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestRead() error: ", err)
	}

	if Model.ID == 0 {
		t.Error(Model.TableName() + "_test.TestRead() error ID =0 ")
	} else {
		t.Log(Model.TableName()+"_test.TestRead() Otvet: ", Model.ID)
	}
}

func TestEmployeesSave(t *testing.T) {
	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &Employee{}
	Model.ID = Employee_ID_Test

	crud := crud_db_Employee{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestSave() error: ", err)
	}

	if Model.ID == 0 {
		t.Error(Model.TableName() + "_test.TestSave() error ID =0")
	}

	err = crud.save(Model)
	if err != nil {
		t.Error("TestSave() error: ", err)
	}
	t.Log(Model.TableName()+"_test.TestSave() Otvet: ", Model.ID)

}

func TestEmployeesDelete(t *testing.T) {
	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &Employee{}
	Model.ID = Employee_ID_Test

	crud := crud_db_Employee{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestDelete() error: ", err)
	}

	if Model.IsDeleted == false {
		err = crud.delete(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

		err = crud.restore(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}
	} else {
		err = crud.restore(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

		err = crud.delete(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

	}

}

func TestEmployeesFind_ByExtID(t *testing.T) {
	config.LoadEnv()
	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &Employee{}
	Model.ExtID = 1
	Model.ConnectionID = CONNECTION_ID_TEST

	crud := crud_db_Employee{}
	err := crud.find_ByExtID(Model)
	if err != nil {
		t.Error("TestFind_ByExtID() error: ", err)
	}

	if Model.ID == 0 {
		t.Error("TestFind_ByExtID() error: ID =0")
	}
}

func TestEmployeesFind_ByLogin(t *testing.T) {

	config.LoadEnv()
	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &Employee{}
	Model.Login = "nechaevaa@atomsbt.ru"

	crud := crud_db_Employee{}
	err := crud.find_ByLogin(Model)
	if err != nil {
		t.Error("TestFind_ByLogin() error: ", err)
	}

	if Model.ID == 0 {
		t.Error("TestFind_ByLogin() error: ID =0")
	}

}

func TestEmployeesFind_ByEMail(t *testing.T) {

	config.LoadEnv()
	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &Employee{}
	Model.Email = "nechaevaa@atomsbt.ru"

	crud := crud_db_Employee{}
	err := crud.find_ByEMail(Model)
	if err != nil {
		t.Error("TestFind_ByEMail() error: ", err)
	}

	if Model.ID == 0 {
		t.Error("TestFind_ByEMail() error: ID =0")
	}

}

func TestEmployeesFind_ByFIO(t *testing.T) {

	config.LoadEnv()
	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &Employee{}
	Model.Name = "Александр"
	Model.SecondName = "Нечаев"
	Model.ParentName = "Андреевич"

	crud := crud_db_Employee{}
	err := crud.find_ByFIO(Model)
	if err != nil {
		t.Error("TestFind_ByFIO() error: ", err)
	}

	if Model.ID == 0 {
		t.Error("TestFind_ByFIO() error: ID =0")
	}

}
