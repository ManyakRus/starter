package object_model

import (
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/config"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/postgres_gorm"
	"testing"
)

const File_ID_Test = 3762
const FILE_FILE_ID_TEST = "6d803deae7dfd0ba8106e48d441b6134"

func TestFilesRead(t *testing.T) {
	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &File{}
	Model.ID = File_ID_Test

	crud := crud_db_File{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestRead() error: ", err)
	}

	if Model.Name == "" {
		t.Error(Model.TableName() + "_test.TestRead() error name= '' ")
	} else {
		t.Log(Model.TableName()+"_test.TestRead() Otvet: ", Model.Name)
	}
}

func TestFilesSave(t *testing.T) {
	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &File{}
	Model.ID = File_ID_Test

	crud := crud_db_File{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestSave() error: ", err)
	}

	if Model.Name == "" {
		t.Error(Model.TableName() + "_test.TestSave() error name= '' ")
	}

	err = crud.save(Model)
	if err != nil {
		t.Error("TestSave() error: ", err)
	}
	t.Log(Model.TableName()+"_test.TestSave() Otvet: ", Model.Name)

}

func TestFilesDelete(t *testing.T) {
	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &File{}
	Model.ID = File_ID_Test

	crud := crud_db_File{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestDelete() error: ", err)
	}

	if Model.IsDeleted == false {
		err = crud.delete(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

		err = crud.restore(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}
	} else {
		err = crud.restore(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

		err = crud.delete(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

	}

}

func TestFilesFind_ByFileId(t *testing.T) {
	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &File{}
	Model.FileID = FILE_FILE_ID_TEST

	crud := crud_db_File{}
	err := crud.find_ByFileId(Model)
	if err != nil {
		t.Log(Model.TableName()+"_test.TestFind_ByFileId() file_id=", FILE_FILE_ID_TEST, " not found")
	} else {
		t.Log(Model.TableName()+"_test.TestFind_ByFileId() Otvet: ", Model.Name)
	}
}
