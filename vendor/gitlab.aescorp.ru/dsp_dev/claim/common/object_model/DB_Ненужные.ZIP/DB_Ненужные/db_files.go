package object_model

import (
	"context"
	"errors"
	"fmt"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/micro"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/postgres_gorm"
	"gorm.io/gorm"
	"time"
)

type crud_db_File struct {
}

// Read - находит запись в БД по ID
func (crud crud_db_File) read(f *File) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.read_ctx(ctx, f)
	return err
}

// Read_ctx - находит запись в БД по ID
func (crud crud_db_File) read_ctx(ctx context.Context, f *File) error {
	var err error

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.First(f, f.ID)
	err = tx.Error

	return err
}

// Save - записывает новый или существующий объект в базу данных
func (crud crud_db_File) save(f *File) error {
	err := crud.create_update(f, false)
	return err
}

// Save_ctx - записывает новый или существующий объект в базу данных
func (crud crud_db_File) save_ctx(ctx context.Context, f *File) error {
	is_create := !micro.BoolFromInt64(f.ID)
	err := crud.create_update_ctx(ctx, f, is_create)
	return err
}

// Update - записывает существующий объект в базу данных
func (crud crud_db_File) update(f *File) error {
	err := crud.create_update(f, false)
	return err
}

// Update_ctx - записывает существующий объект в базу данных
func (crud crud_db_File) update_ctx(ctx context.Context, f *File) error {
	err := crud.create_update_ctx(ctx, f, false)
	return err
}

// Create - записывает новый объект в базу данных
func (crud crud_db_File) create(f *File) error {
	err := crud.create_update(f, true)
	return err
}

// Create_ctx - записывает новый объект в базу данных
func (crud crud_db_File) create_ctx(ctx context.Context, f *File) error {
	err := crud.create_update_ctx(ctx, f, true)
	return err
}

// create_update - записывает объект в базу данных
func (crud crud_db_File) create_update(f *File, is_create bool) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.create_update_ctx(ctx, f, is_create)
	return err
}

// create_update_ctx - записывает объект в базу данных
func (crud crud_db_File) create_update_ctx(ctx context.Context, f *File, is_create bool) error {
	var err error

	// проверка ID
	if is_create == true {
		if f.ID != 0 {
			TextError := fmt.Sprint("db.Save() ", f.TableName(), " error: id !=0")
			err = errors.New(TextError)
			return err
		}
	} else if f.ID == 0 {
		TextError := fmt.Sprint("db.Save() ", f.TableName(), " error: id =0")
		err = errors.New(TextError)
		return err
	}

	//
	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	//заполним даты
	Now := time.Now()
	f.ModifiedAt = Now
	if f.IsDeleted == true && f.DeletedAt.IsZero() == true {
		f.DeletedAt = Now
	} else if f.IsDeleted == false && f.DeletedAt.IsZero() == false {
		f.DeletedAt = time.Time{}
	}

	//колонки с null
	tx := db
	MassOmit := make([]string, 0)
	var ColumnName string

	ColumnName = "ParentID"
	if f.ParentID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "DeletedAt"
	if f.DeletedAt.IsZero() == true {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "TemplateID"
	if f.TemplateID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "FileID"
	if f.FileID == "" {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "EmployeeID"
	if f.EmployeeID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "BranchID"
	if f.BranchID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "TableNameID"
	if f.TableNameID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "FileTypeID"
	if f.FileTypeID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "ExtID"
	if f.ExtID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	//игнор пустых колонок
	tx = tx.Omit(MassOmit...)

	//запись
	if is_create == true {
		tx = tx.Create(f)
	} else {
		tx = tx.Save(f)
	}
	err = tx.Error
	if err != nil {
		return err
	}

	//запишем NULL в пустые колонки
	for ff := 0; ff < len(MassOmit); ff++ {
		ColumnName := MassOmit[ff]
		tx = db.First(f).Update(ColumnName, gorm.Expr("NULL"))

		err = tx.Error
		if err != nil {
			TextError := fmt.Sprint("db.Update() ", f.TableName(), " id: ", f.ID, " error: ", err)
			err = errors.New(TextError)
			return err
		}
	}

	return err
}

// Delete - записывает is_deleted = true
func (crud crud_db_File) delete(f *File) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.delete_ctx(ctx, f)
	return err
}

// Delete_ctx - записывает is_deleted = true
func (crud crud_db_File) delete_ctx(ctx context.Context, f *File) error {
	var err error

	var f2 *File
	f2.ID = f.ID
	err = crud.read_ctx(ctx, f2)
	if err != nil {
		return err
	}

	f.IsDeleted = true
	f2.IsDeleted = true

	err = crud.save_ctx(ctx, f2)

	return err
}

// Restore - записывает is_deleted = true
func (crud crud_db_File) restore(f *File) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.restore_ctx(ctx, f)
	return err
}

// Restore_ctx - записывает is_deleted = true
func (crud crud_db_File) restore_ctx(ctx context.Context, f *File) error {
	var err error

	var f2 *File
	f2.ID = f.ID
	err = crud.read_ctx(ctx, f2)
	if err != nil {
		return err
	}

	f.IsDeleted = false
	f2.IsDeleted = false

	err = crud.save_ctx(ctx, f2)

	return err
}

// Find_ByFileId - находит запись в БД по File_id
func (crud crud_db_File) find_ByFileId(f *File) error {
	var err error

	if f.FileID == "" {
		err = errors.New("Error: file_id = ''")
		return err
	}

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.find_ByFileId_ctx(ctx, f)

	return err
}

// Find_ByFileId_ctx - находит запись в БД по File_id
func (crud crud_db_File) find_ByFileId_ctx(ctx context.Context, f *File) error {
	var err error

	if f.FileID == "" {
		err = errors.New("Error: file_id = ''")
		return err
	}

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.Where("file_id = ?", f.FileID).First(f)
	err = tx.Error

	return err
}

// Find_ByFull_name - находит запись в БД по File_id
func (crud crud_db_File) find_ByFull_name(f *File) error {
	var err error

	if f.FullName == "" {
		err = errors.New("Error: full_name =''")
		return err
	}

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.find_ByFull_name_ctx(ctx, f)

	return err
}

// Find_ByFull_name_ctx - находит запись в БД по File_id
func (crud crud_db_File) find_ByFull_name_ctx(ctx context.Context, f *File) error {
	var err error

	if f.FullName == "" {
		err = errors.New("Error: full_name = ''")
		return err
	}

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.Where("full_name = ?", f.FullName).First(f)
	err = tx.Error

	return err
}

//// Find_ByExtID - находит запись в БД по ext_id и connection_id
//func (crud crud_db_File) find_ByExtID() error {
//	var err error
//
//	if f.ExtID <= 0 {
//		err = errors.New("Error: ext_id <=0")
//		return err
//	}
//
//	//
//	ctxMain := context.Background()
//	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
//	defer ctxCancelFunc()
//
//	err = f.find_ByExtID_ctx(ctx)
//
//	return err
//}
//
//// Find_ByExtID_ctx - находит запись в БД по ext_id и connection_id
//func (crud crud_db_File) find_ByExtID_ctx(ctx context.Context) (error) {
//	var err error
//
//	if f.ExtID <= 0 {
//		err = errors.New("Error: ext_id <=0")
//		return err
//	}
//
//	db := postgres_gorm.GetConnection()
//	db.WithContext(ctx)
//
//	tx := db.Where("ext_id = ?", f.ExtID).Where("connection_id = ?", f.ConnectionID).First(f)
//	err = tx.Error
//
//	return err
//}
