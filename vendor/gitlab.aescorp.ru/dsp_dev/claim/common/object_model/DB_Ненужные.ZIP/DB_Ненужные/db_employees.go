package object_model

import (
	"context"
	"errors"
	"fmt"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/micro"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/postgres_gorm"
	"gorm.io/gorm"
	"time"
)

type crud_db_Employee struct {
}

// Read - находит запись в БД по ID
func (crud crud_db_Employee) read(e *Employee) error {
	var err error

	//log.Trace("start Read() ", TableName, " id: ", id)
	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.read_ctx(ctx, e)
	return err
}

// Read_ctx - находит запись в БД по ID
func (crud crud_db_Employee) read_ctx(ctx context.Context, e *Employee) error {
	var err error

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.First(e, e.ID)
	err = tx.Error

	return err
}

// Save - записывает новый или существующий объект в базу данных
func (crud crud_db_Employee) save(e *Employee) error {
	err := crud.create_update(e, false)
	return err
}

// Save_ctx - записывает новый или существующий объект в базу данных
func (crud crud_db_Employee) save_ctx(ctx context.Context, e *Employee) error {
	is_create := !micro.BoolFromInt64(e.ID)
	err := crud.create_update_ctx(ctx, e, is_create)
	return err
}

// Update - записывает существующий объект в базу данных
func (crud crud_db_Employee) update(e *Employee) error {
	err := crud.create_update(e, false)
	return err
}

// Update_ctx - записывает существующий объект в базу данных
func (crud crud_db_Employee) update_ctx(ctx context.Context, e *Employee) error {
	err := crud.create_update_ctx(ctx, e, false)
	return err
}

// Create - записывает новый объект в базу данных
func (crud crud_db_Employee) create(e *Employee) error {
	err := crud.create_update(e, true)
	return err
}

// Create_ctx - записывает новый объект в базу данных
func (crud crud_db_Employee) create_ctx(ctx context.Context, e *Employee) error {
	err := crud.create_update_ctx(ctx, e, true)
	return err
}

// create_update - записывает объект в базу данных
func (crud crud_db_Employee) create_update(e *Employee, is_create bool) error {
	var err error

	//log.Trace("start Save() ", TableName, " id: ", m.ID)

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.create_update_ctx(ctx, e, is_create)
	return err
}

// create_update_ctx - записывает объект в базу данных
func (crud crud_db_Employee) create_update_ctx(ctx context.Context, e *Employee, is_create bool) error {
	var err error

	//log.Trace("start Save() ", TableName, " id: ", m.ID)

	// проверка ID
	if is_create == true {
		if e.ID != 0 {
			TextError := fmt.Sprint("db.Save() ", e.TableName(), " error: id !=0")
			//log.Panic(sError)
			err = errors.New(TextError)
			return err
		}
	} else if e.ID == 0 {
		TextError := fmt.Sprint("db.Save() ", e.TableName(), " error: id =0")
		err = errors.New(TextError)
		//log.Panic(sError)
		return err
	}

	//
	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	//заполним даты
	Now := time.Now()
	e.ModifiedAt = Now
	if e.IsDeleted == true && e.DeletedAt.IsZero() == true {
		e.DeletedAt = Now
	} else if e.IsDeleted == false && e.DeletedAt.IsZero() == false {
		e.DeletedAt = time.Time{}
	}

	//колонки с null
	tx := db
	MassOmit := make([]string, 0)
	var ColumnName string

	ColumnName = "ParentID"
	if e.ParentID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "DeletedAt"
	if e.DeletedAt.IsZero() == true {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "ExtID"
	if e.ExtID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	//игнор пустых колонок
	tx = tx.Omit(MassOmit...)

	//запись
	if is_create == true {
		tx = tx.Create(e)
	} else {
		tx = tx.Save(e)
	}
	err = tx.Error
	if err != nil {
		return err
	}

	//запишем NULL в пустые колонки
	for f := 0; f < len(MassOmit); f++ {
		ColumnName := MassOmit[f]
		tx = db.First(e).Update(ColumnName, gorm.Expr("NULL"))

		err = tx.Error
		if err != nil {
			TextError := fmt.Sprint("db.Update() ", e.TableName(), " id: ", e.ID, " error: ", err)
			err = errors.New(TextError)
			return err
			//log.Panic(sError)
		}
	}

	return err
}

// Delete - записывает is_deleted = true
func (crud crud_db_Employee) delete(e *Employee) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.delete_ctx(ctx, e)
	return err
}

// Delete_ctx - записывает is_deleted = true
func (crud crud_db_Employee) delete_ctx(ctx context.Context, e *Employee) error {
	var err error

	var e2 *Employee
	e2.ID = e.ID
	err = crud.read_ctx(ctx, e2)
	if err != nil {
		return err
	}

	e.IsDeleted = true
	e2.IsDeleted = true

	err = crud.save_ctx(ctx, e2)

	return err
}

// Restore - записывает is_deleted = true
func (crud crud_db_Employee) restore(e *Employee) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.restore_ctx(ctx, e)
	return err
}

// Restore_ctx - записывает is_deleted = true
func (crud crud_db_Employee) restore_ctx(ctx context.Context, e *Employee) error {
	var err error

	var e2 *Employee
	e2.ID = e.ID
	err = crud.read_ctx(ctx, e2)
	if err != nil {
		return err
	}

	e.IsDeleted = false
	e2.IsDeleted = false

	err = crud.save_ctx(ctx, e2)

	return err
}

// Find_ByExtID - находит запись в БД по ext_id и connection_id
func (crud crud_db_Employee) find_ByExtID(e *Employee) error {
	var err error

	if e.ExtID <= 0 {
		err = errors.New("Error: ext_id <=0")
		return err
	}

	//
	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.find_ByExtID_ctx(ctx, e)

	return err
}

// Find_ByExtID_ctx - находит запись в БД по ext_id и connection_id
func (crud crud_db_Employee) find_ByExtID_ctx(ctx context.Context, e *Employee) error {
	var err error
	//log.Trace("start Find_ByExtID() ", TableName, " ext_id: ", ext_id)

	if e.ExtID <= 0 {
		err = errors.New("Error: ext_id <=0")
		return err
	}

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.Where("ext_id = ?", e.ExtID).Where("connection_id = ?", e.ConnectionID).First(e)
	err = tx.Error

	return err
}

// Find_ByLogin - находит запись в БД по Login
func (crud crud_db_Employee) find_ByLogin(e *Employee) error {
	var err error

	if e.Login == "" {
		err = errors.New("Error: login =''")
		return err
	}

	//
	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.find_ByLogin_ctx(ctx, e)

	return err
}

// Find_ByLogin_ctx - находит запись в БД по Login
func (crud crud_db_Employee) find_ByLogin_ctx(ctx context.Context, e *Employee) error {
	var err error

	if e.Login == "" {
		err = errors.New("Error: login =''")
		return err
	}

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.Where("login = ?", e.Login).First(e)
	err = tx.Error

	return err
}

// Find_ByEMail - находит запись в БД по EMail
func (crud crud_db_Employee) find_ByEMail(e *Employee) error {
	var err error

	if e.Email == "" {
		err = errors.New("Error: email =''")
		return err
	}

	//
	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.find_ByEMail_ctx(ctx, e)

	return err
}

// Find_ByEMail_ctx - находит запись в БД по EMail
func (crud crud_db_Employee) find_ByEMail_ctx(ctx context.Context, e *Employee) error {
	var err error
	//log.Trace("start Find_ByExtID() ", TableName, " ext_id: ", ext_id)

	if e.Email == "" {
		err = errors.New("Error: email =''")
		return err
	}

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.Where("email = ?", e.Email).First(e)
	err = tx.Error

	return err
}

// Find_ByFIO - находит запись в БД по name + second_name + parent_name
func (crud crud_db_Employee) find_ByFIO(e *Employee) error {
	var err error

	if e.Name == "" && e.SecondName == "" && e.ParentName == "" {
		err = errors.New("Error: name + second_name + parent_name = ''")
		return err
	}

	//
	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.find_ByFIO_ctx(ctx, e)

	return err
}

// Find_ByFIO_ctx - находит запись в БД по name + second_name + parent_name
func (crud crud_db_Employee) find_ByFIO_ctx(ctx context.Context, e *Employee) error {
	var err error

	if e.Name == "" && e.SecondName == "" && e.ParentName == "" {
		err = errors.New("Error: name + second_name + parent_name = ''")
		return err
	}

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.Where("name = ?", e.Name).Where("second_name = ?", e.SecondName).Where("parent_name = ?", e.ParentName).First(e)
	err = tx.Error

	return err
}
