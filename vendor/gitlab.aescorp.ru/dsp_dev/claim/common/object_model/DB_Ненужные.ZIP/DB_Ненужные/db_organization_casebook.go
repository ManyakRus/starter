package object_model

import (
	"context"
	"errors"
	"fmt"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/micro"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/postgres_gorm"
	"gorm.io/gorm"
	"time"
)

type crud_db_OrganizationCasebook struct {
}

// Read - находит запись в БД по ID
func (crud crud_db_OrganizationCasebook) read(o *OrganizationCasebook) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.read_ctx(ctx, o)

	return err
}

// Read_ctx - находит запись в БД по ID
func (crud crud_db_OrganizationCasebook) read_ctx(ctx context.Context, o *OrganizationCasebook) error {
	var err error

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.First(o, o.ID)
	err = tx.Error

	return err
}

// Save - записывает новый или существующий объект в базу данных
func (crud crud_db_OrganizationCasebook) save(o *OrganizationCasebook) error {
	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err := crud.save_ctx(ctx, o)
	return err
}

// Save_ctx - записывает новый или существующий объект в базу данных
func (crud crud_db_OrganizationCasebook) save_ctx(ctx context.Context, o *OrganizationCasebook) error {
	is_create := !micro.BoolFromInt64(o.ID)
	err := crud.create_update_ctx(ctx, o, is_create)
	return err
}

// Update - записывает существующий объект в базу данных
func (crud crud_db_OrganizationCasebook) update(o *OrganizationCasebook) error {
	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err := crud.update_ctx(ctx, o)
	return err
}

// Update_ctx - записывает существующий объект в базу данных
func (crud crud_db_OrganizationCasebook) update_ctx(ctx context.Context, o *OrganizationCasebook) error {
	err := crud.create_update_ctx(ctx, o, false)
	return err
}

// Create - записывает новый объект в базу данных
func (crud crud_db_OrganizationCasebook) create(o *OrganizationCasebook) error {
	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err := crud.create_ctx(ctx, o)
	return err
}

// Create_ctx - записывает новый объект в базу данных
func (crud crud_db_OrganizationCasebook) create_ctx(ctx context.Context, o *OrganizationCasebook) error {
	err := crud.create_update_ctx(ctx, o, true)
	return err
}

// create_update - записывает объект в базу данных
func (crud crud_db_OrganizationCasebook) create_update(o *OrganizationCasebook, need_create bool) error {
	var err error

	//
	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	//
	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	err = crud.create_update_ctx(ctx, o, need_create)

	return err
}

// create_update_ctx - записывает объект в базу данных
func (crud crud_db_OrganizationCasebook) create_update_ctx(ctx context.Context, o *OrganizationCasebook, need_create bool) error {
	var err error

	// проверка ID
	if need_create == true {
		if o.ID != 0 {
			TextError := fmt.Sprint("db.Save() ", o.TableName(), " error: id !=0")
			err = errors.New(TextError)
			return err
		}
	} else if o.ID == 0 {
		TextError := fmt.Sprint("db.Save() ", o.TableName(), " error: id =0")
		err = errors.New(TextError)
		return err
	}

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	//заполним даты
	Now := time.Now()
	o.ModifiedAt = Now
	if o.IsDeleted == true && o.DeletedAt.IsZero() == true {
		o.DeletedAt = Now
	} else if o.IsDeleted == false && o.DeletedAt.IsZero() == false {
		o.DeletedAt = time.Time{}
	}

	//колонки с null
	tx := db
	MassOmit := make([]string, 0)
	var ColumnName string

	ColumnName = "DeletedAt"
	if o.DeletedAt.IsZero() == true {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "OrganizationID"
	if o.OrganizationID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "JSONFileID"
	if o.JSONFileID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "PDFFileID"
	if o.PDFFileID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "ExtID"
	if o.ExtID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	//игнор пустых колонок
	tx = tx.Omit(MassOmit...)

	//запись
	if need_create == true {
		tx = tx.Create(o)
	} else {
		tx = tx.Save(o)
	}
	err = tx.Error
	if err != nil {
		return err
	}

	//запишем NULL в пустые колонки
	for f := 0; f < len(MassOmit); f++ {
		ColumnName := MassOmit[f]
		tx = db.First(o).Update(ColumnName, gorm.Expr("NULL"))

		err = tx.Error
		if err != nil {
			TextError := fmt.Sprint("db.Update() ", o.TableName(), " id: ", o.ID, " error: ", err)
			err = errors.New(TextError)
			return err
		}
	}

	return err
}

// Delete - записывает is_deleted = true
func (crud crud_db_OrganizationCasebook) delete(o *OrganizationCasebook) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.delete_ctx(ctx, o)
	return err
}

// Delete_ctx - записывает is_deleted = true
func (crud crud_db_OrganizationCasebook) delete_ctx(ctx context.Context, o *OrganizationCasebook) error {
	var err error

	var o2 *OrganizationCasebook
	o2.ID = o.ID
	err = crud.read_ctx(ctx, o2)
	if err != nil {
		return err
	}

	o.IsDeleted = true
	o2.IsDeleted = true

	err = crud.save_ctx(ctx, o2)

	return err
}

// Restore - записывает is_deleted = true
func (crud crud_db_OrganizationCasebook) restore(o *OrganizationCasebook) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.restore_ctx(ctx, o)
	return err
}

// Restore_ctx - записывает is_deleted = true
func (crud crud_db_OrganizationCasebook) restore_ctx(ctx context.Context, o *OrganizationCasebook) error {
	var err error

	var o2 *OrganizationCasebook
	o2.ID = o.ID
	err = crud.read_ctx(ctx, o2)
	if err != nil {
		return err
	}

	o.IsDeleted = false
	o2.IsDeleted = false

	err = crud.save_ctx(ctx, o2)

	return err
}

//// Find_ByExtID - находит запись в БД по ext_id и connection_id
//func (crud crud_db_OrganizationCasebook) find_ByExtID() error {
//	var err error
//
//	if o.ExtID <= 0 {
//		return err
//	}
//
//	//
//	ctxMain := context.Background()
//	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
//	defer ctxCancelFunc()
//
//	err = o.find_ByExtID_ctx(ctx)
//	return err
//}

//// Find_ByExtID_ctx - находит запись в БД по ext_id и connection_id
//func (crud crud_db_OrganizationCasebook) find_ByExtID_ctx(ctx context.Context) (error) {
//	var err error
//
//	if o.ExtID <= 0 {
//		err = errors.New("Error: ext_id <=0")
//		return err
//	}
//
//	db := postgres_gorm.GetConnection()
//	db.WithContext(ctx)
//
//	tx := db.Where("ext_id = ?", o.ExtID).Where("connection_id = ?", o.ConnectionID).First(&o)
//	err = tx.Error
//
//	return err
//}

// Find_ByInnKpp - находит запись в БД по ИНН и КПП
func (crud crud_db_OrganizationCasebook) find_ByInnKpp(o *OrganizationCasebook) error {
	var err error

	if o.INN == "" {
		err = errors.New("Error: INN =''")
		return err
	}

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.find_ByInnKpp_ctx(ctx, o)
	return err
}

// Find_ByInnKpp_ctx - находит запись в БД по ИНН и КПП
func (crud crud_db_OrganizationCasebook) find_ByInnKpp_ctx(ctx context.Context, o *OrganizationCasebook) error {
	var err error

	if o.INN == "" {
		err = errors.New("Error: INN =''")
		return err
	}

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.Where("INN = ?", o.INN).Where("KPP = ?", o.KPP).First(o)
	err = tx.Error

	return err
}

// Find_ByOrganizationId - находит запись в БД по organization_id
func (crud crud_db_OrganizationCasebook) find_ByOrganizationId(o *OrganizationCasebook) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.find_ByOrganizationId_ctx(ctx, o)

	return err
}

// Find_ByOrganizationId_ctx - находит запись в БД по organization_id
func (crud crud_db_OrganizationCasebook) find_ByOrganizationId_ctx(ctx context.Context, o *OrganizationCasebook) error {
	var err error

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.Where("organization_id = ?", o.OrganizationID).First(o)
	err = tx.Error

	return err
}
