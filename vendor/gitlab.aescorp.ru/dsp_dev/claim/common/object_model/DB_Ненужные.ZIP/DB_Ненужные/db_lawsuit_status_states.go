package object_model

import (
	"context"
	"errors"
	"fmt"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/micro"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/postgres_gorm"
	"gorm.io/gorm"
	"strconv"
	"strings"
	"time"
)

type crud_db_LawsuitStatusState struct {
}

// Read - находит запись в БД по ID
func (crud crud_db_LawsuitStatusState) read(l *LawsuitStatusState) error {
	var err error

	//log.Trace("start Read() ", TableName, " id: ", id)
	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.read_ctx(ctx, l)
	return err
}

// Read_ctx - находит запись в БД по ID
func (crud crud_db_LawsuitStatusState) read_ctx(ctx context.Context, l *LawsuitStatusState) error {
	var err error

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	tx := db.First(l)
	err = tx.Error

	return err
}

// Save - записывает новый или существующий объект в базу данных
func (crud crud_db_LawsuitStatusState) save(l *LawsuitStatusState) error {
	err := crud.create_update(l, false)
	return err
}

// Save_ctx - записывает новый или существующий объект в базу данных
func (crud crud_db_LawsuitStatusState) save_ctx(ctx context.Context, l *LawsuitStatusState) error {
	is_create := !micro.BoolFromInt64(l.ID)
	err := crud.create_update_ctx(ctx, l, is_create)
	return err
}

// Update - записывает существующий объект в базу данных
func (crud crud_db_LawsuitStatusState) update(l *LawsuitStatusState) error {
	err := crud.create_update(l, false)
	return err
}

// Update_ctx - записывает существующий объект в базу данных
func (crud crud_db_LawsuitStatusState) update_ctx(ctx context.Context, l *LawsuitStatusState) error {
	err := crud.create_update_ctx(ctx, l, false)
	return err
}

// Create - записывает новый объект в базу данных
func (crud crud_db_LawsuitStatusState) create(l *LawsuitStatusState) error {
	err := crud.create_update(l, true)
	return err
}

// Create_ctx - записывает новый объект в базу данных
func (crud crud_db_LawsuitStatusState) create_ctx(ctx context.Context, l *LawsuitStatusState) error {
	err := crud.create_update_ctx(ctx, l, true)
	return err
}

// create_update - записывает объект в базу данных
func (crud crud_db_LawsuitStatusState) create_update(l *LawsuitStatusState, is_create bool) error {
	var err error

	//log.Trace("start Save() ", TableName, " id: ", m.ID)

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.create_update_ctx(ctx, l, is_create)
	return err
}

// create_update_ctx - записывает объект в базу данных
func (crud crud_db_LawsuitStatusState) create_update_ctx(ctx context.Context, l *LawsuitStatusState, is_create bool) error {
	var err error

	//log.Trace("start Save() ", TableName, " id: ", m.ID)

	// проверка ID
	if is_create == true {
		if l.ID != 0 {
			TextError := fmt.Sprint("db.Save() ", l.TableName(), " error: id !=0")
			//log.Panic(sError)
			err = errors.New(TextError)
			return err
		}
	} else if l.ID == 0 {
		TextError := fmt.Sprint("db.Save() ", l.TableName(), " error: id =0")
		err = errors.New(TextError)
		//log.Panic(sError)
		return err
	}

	//
	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	//заполним даты
	Now := time.Now()
	l.ModifiedAt = Now
	if l.IsDeleted == true && l.DeletedAt.IsZero() == true {
		l.DeletedAt = Now
	} else if l.IsDeleted == false && l.DeletedAt.IsZero() == false {
		l.DeletedAt = time.Time{}
	}

	//колонки с null
	tx := db
	MassOmit := make([]string, 0)
	var ColumnName string

	ColumnName = "DeletedAt"
	if l.DeletedAt.IsZero() == true {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "ExtID"
	if l.ExtID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	ColumnName = "CommentID"
	if l.CommentID == 0 {
		MassOmit = append(MassOmit, ColumnName)
	}

	//игнор пустых колонок
	tx = tx.Omit(MassOmit...)

	//запись
	if is_create == true {
		tx = tx.Create(l)
	} else {
		tx = tx.Save(l)
	}
	err = tx.Error
	if err != nil {
		return err
	}

	//запишем NULL в пустые колонки
	for f := 0; f < len(MassOmit); f++ {
		ColumnName := MassOmit[f]
		tx = db.First(l).Update(ColumnName, gorm.Expr("NULL"))

		err = tx.Error
		if err != nil {
			TextError := fmt.Sprint("db.Update() ", l.TableName(), " id: ", l.ID, " error: ", err)
			err = errors.New(TextError)
			return err
			//log.Panic(sError)
		}
	}

	return err
}

// Delete - записывает is_deleted = true
func (crud crud_db_LawsuitStatusState) delete(l *LawsuitStatusState) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.delete_ctx(ctx, l)
	return err
}

// Delete_ctx - записывает is_deleted = true
func (crud crud_db_LawsuitStatusState) delete_ctx(ctx context.Context, l *LawsuitStatusState) error {
	var err error

	var l2 *LawsuitStatusState
	l2.ID = l.ID
	err = crud.read_ctx(ctx, l2)
	if err != nil {
		return err
	}

	l.IsDeleted = true
	l2.IsDeleted = true

	err = crud.save_ctx(ctx, l2)

	return err
}

// Restore - записывает is_deleted = true
func (crud crud_db_LawsuitStatusState) restore(l *LawsuitStatusState) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	err = crud.restore_ctx(ctx, l)
	return err
}

// Restore_ctx - записывает is_deleted = true
func (crud crud_db_LawsuitStatusState) restore_ctx(ctx context.Context, l *LawsuitStatusState) error {
	var err error

	var l2 *LawsuitStatusState
	l2.ID = l.ID
	err = crud.read_ctx(ctx, l2)
	if err != nil {
		return err
	}

	l.IsDeleted = false
	l2.IsDeleted = false

	err = crud.save_ctx(ctx, l2)

	return err
}

//// Find_ByExtID - находит запись в БД по ext_id и connection_id
//func Find_ByExtID(ext_id int64, connection_id int64) (LawsuitStatusState, error) {
//	var Otvet LawsuitStatusState
//	var err error
//
//	if ext_id <= 0 {
//		err = errors.New("Error: ext_id <=0")
//		return Otvet, err
//	}
//
//	//
//	ctxMain := context.Background()
//	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
//	defer ctxCancelFunc()
//
//	Otvet, err = Find_ByExtID_ctx(ctx, ext_id, connection_id)
//
//	return Otvet, err
//}
//
//// Find_ByExtID_ctx - находит запись в БД по ext_id и connection_id
//func Find_ByExtID_ctx(ctx context.Context, ext_id int64, connection_id int64) (LawsuitStatusState, error) {
//	var Otvet LawsuitStatusState
//	var err error
//	//log.Trace("start Find_ByExtID() ", TableName, " ext_id: ", ext_id)
//
//	if ext_id <= 0 {
//		err = errors.New("Error: ext_id <=0")
//		return Otvet, err
//	}
//
//	db := postgres_gorm.GetConnection()
//	db.WithContext(ctx)
//
//	tx := db.Where("ext_id = ?", ext_id).Where("connection_id = ?", connection_id).First(&Otvet)
//	err = tx.Error
//
//	return Otvet, err
//}

func LawsuitStatusState_fill_from_Lawsuit(Lawsuit_id int64, Status_id int64) error {
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	TextSQL := `
INSERT INTO public.lawsuit_status_states as lss (
	lawsuit_id,
	status_at,
	modified_at,
	total_debt,
	invoice_sum,
	pay_sum,
	main_sum,
	penalty_sum,
	penny_sum,
	restrict_sum,
	status_id                                                 
	)
SELECT 
	l.id, 
	Now(),
	Now(),
	debt_sum,
	invoice_sum,
	pay_sum,
	main_sum,
	penalty as penalty_sum,
	penny as penny_sum,
	restrict_sum,
	:status_id as status_id
from 
    public.lawsuits as l 
WHERE 1=1
	and l.id = :lawsuit_id
	
ON CONFLICT (lawsuit_id, status_id) DO UPDATE
SET
	lawsuit_id = EXCLUDED.lawsuit_id,
	status_at = Now(),
	modified_at = Now(),
	total_debt = EXCLUDED.total_debt,
	invoice_sum = EXCLUDED.invoice_sum,
	pay_sum = EXCLUDED.pay_sum,
	main_sum = EXCLUDED.main_sum,
	penalty_sum = EXCLUDED.penalty_sum,
	penny_sum = EXCLUDED.penny_sum,
	restrict_sum = EXCLUDED.restrict_sum,
	status_id = EXCLUDED.status_id
`

	TextSQL = strings.ReplaceAll(TextSQL, ":lawsuit_id", strconv.Itoa(int(Lawsuit_id)))
	TextSQL = strings.ReplaceAll(TextSQL, ":status_id", strconv.Itoa(int(Status_id)))

	tx := db.Exec(TextSQL)
	err = tx.Error

	return err
}

func LawsuitStatusState_FindDebtSum(lawsuit_id, status_id int64) (float64, error) {
	var Otvet float64
	var err error

	ctxMain := context.Background()
	ctx, ctxCancelFunc := context.WithTimeout(ctxMain, time.Second*time.Duration(TIMEOUT_DB_SECONDS))
	defer ctxCancelFunc()

	db := postgres_gorm.GetConnection()
	db.WithContext(ctx)

	lawsuitStatusState := LawsuitStatusState{}
	tx := db.Model(lawsuitStatusState).Where("lawsuit_id = ?", lawsuit_id).Where("status_id = ?", status_id).First(&lawsuitStatusState)
	err = tx.Error
	Otvet = lawsuitStatusState.TotalDebt

	return Otvet, err
}
