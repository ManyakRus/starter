package object_model

import (
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/config"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/postgres_gorm"
	"testing"
)

const MessageSendStatus_ID_Test = 1

func TestMessageSendStatusRead(t *testing.T) {
	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &MessageSendStatus{}
	Model.ID = MessageSendStatus_ID_Test

	crud := crud_db_MessageSendStatus{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestRead() error: ", err)
	}

	if Model.ID == 0 {
		t.Error(Model.TableName() + "_test.TestRead() error ID =0 ")
	} else {
		t.Log(Model.TableName()+"_test.TestRead() Otvet: ", Model.ID)
	}
}

func TestMessageSendStatusSave(t *testing.T) {
	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &MessageSendStatus{}
	Model.ID = MessageSendStatus_ID_Test

	crud := crud_db_MessageSendStatus{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestSave() error: ", err)
	}

	if Model.ID == 0 {
		t.Error(Model.TableName() + "_test.TestSave() error ID =0 ")
	}

	err = crud.save(Model)
	if err != nil {
		t.Error("TestSave() error: ", err)
	}
	t.Log(Model.TableName()+"_test.TestSave() Otvet: ", Model.ID)

}

func TestMessageSendStatusDelete(t *testing.T) {
	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &MessageSendStatus{}
	Model.ID = MessageSendStatus_ID_Test

	crud := crud_db_MessageSendStatus{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestDelete() error: ", err)
	}

	if Model.IsDeleted == false {
		err = crud.delete(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

		err = crud.restore(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}
	} else {
		err = crud.restore(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

		err = crud.delete(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

	}

}

//func TestMessageSendStatusFind_ByExtID(t *testing.T) {
//	config.LoadEnv()
//	postgres_gorm.Connect()
//	defer postgres_gorm.CloseConnection()
//
//	Otvet, err := Find_ByExtID(1, constants.CONNECTION_ID_TEST)
//	if err != nil {
//		t.Error("TestFind_ByExtID() error: ", err)
//	}
//
//	if Otvet.ID == 0 {
//		t.Error("TestFind_ByExtID() error: ID =0")
//	}
//}
