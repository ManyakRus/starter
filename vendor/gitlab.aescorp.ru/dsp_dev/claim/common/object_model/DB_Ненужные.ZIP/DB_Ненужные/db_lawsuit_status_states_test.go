package object_model

import (
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/config"
	"gitlab.aescorp.ru/dsp_dev/claim/nikitin/postgres_gorm"
	"testing"
)

var LAWSUIT_ID_TEST int64 = 6013

const LawsuitStatusState_ID_Test = 1

func TestLawsuitStatusStateRead(t *testing.T) {
	t.SkipNow() //временно, там нет ни одной строки

	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &LawsuitStatusState{}
	Model.ID = LawsuitStatusState_ID_Test

	crud := crud_db_LawsuitStatusState{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestRead() error: ", err)
	}

	if Model.ID == 0 {
		t.Error(Model.TableName() + "_test.TestRead() error ID =0 ")
	} else {
		t.Log(Model.TableName()+"_test.TestRead() Otvet: ", Model.ID)
	}
}

func TestLawsuitStatusStateSave(t *testing.T) {
	t.SkipNow() //временно, там нет ни одной строки

	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &LawsuitStatusState{}
	Model.ID = LawsuitStatusState_ID_Test

	crud := crud_db_LawsuitStatusState{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestSave() error: ", err)
	}

	if Model.ID == 0 {
		t.Error(Model.TableName() + "_test.TestSave() error ID =0 ")
	}

	err = crud.save(Model)
	if err != nil {
		t.Error("TestSave() error: ", err)
	}
	t.Log(Model.TableName()+"_test.TestSave() Otvet: ", Model.ID)

}

func TestLawsuitStatusStateDelete(t *testing.T) {
	t.SkipNow() //временно, там нет ни одной строки

	config.LoadEnv()

	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Model := &LawsuitStatusState{}
	Model.ID = LawsuitStatusState_ID_Test

	crud := crud_db_LawsuitStatusState{}
	err := crud.read(Model)
	if err != nil {
		t.Error("TestDelete() error: ", err)
	}

	if Model.IsDeleted == false {
		err = crud.delete(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

		err = crud.restore(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}
	} else {
		err = crud.restore(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

		err = crud.delete(Model)
		if err != nil {
			t.Error("TestDelete() error: ", err)
		}

	}

}

//func TestLawsuitStatusStateFind_ByExtID(t *testing.T) {
//	t.SkipNow() //временно, там нет ни одной строки
//
//	config.LoadEnv()
//	postgres_gorm.Connect()
//	defer postgres_gorm.CloseConnection()
//
//	Otvet, err := Find_ByExtID(1, constants.CONNECTION_ID_TEST)
//	if err != nil {
//		t.Error("TestFind_ByExtID() error: ", err)
//	}
//
//	if Otvet.ID == 0 {
//		t.Error("TestFind_ByExtID() error: ID =0")
//	}
//}

func TestFillLawsuitStatusStates_from_Lawsuit(t *testing.T) {
	config.LoadEnv()
	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	err := LawsuitStatusState_fill_from_Lawsuit(LAWSUIT_ID_TEST, 1)
	if err != nil {
		t.Error("TestFillLawsuitStatusStates_from_Lawsuit() error: ", err)
	}
}

func TestFindDebtSum_from_lawsuit_status_states(t *testing.T) {
	config.LoadEnv()
	postgres_gorm.Connect()
	defer postgres_gorm.CloseConnection()

	Otvet, err := LawsuitStatusState_FindDebtSum(6010, 1)
	if err != nil {
		t.Error("TestFindDebtSum_from_lawsuit_status_states() error: ", err)
	}
	if Otvet == 0 {
		t.Error("TestFindDebtSum_from_lawsuit_status_states() error: Otvet =0")
	}
}
